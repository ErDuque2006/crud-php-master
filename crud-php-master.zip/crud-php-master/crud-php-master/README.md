# CRUD PHP MySQL para descargar, con Javascript y Bootstrap Comparto el Codigo
<img src="https://i0.wp.com/www.configuroweb.com/wp-content/uploads/2019/09/CRUD-PHP-MySQL-para-descargar-con-Javascript-y-Bootstrap-Comparto-el-Codigo.png?resize=800%2C500&ssl=1">
Todos los detalles sobre esta aplicación los puedes ver en el siguiente enlace:

https://www.configuroweb.com/crud-php-mysql-para-descargar-con-javascript-y-bootstrap-comparto-el-codigo/
